
def rot15(mensaje):
    mensaje = mensaje
    abc="abcdefghijklmnopqrstuvwxyz"
    aux=""

    for i in mensaje:
        if i == ' ':  
            aux += ' '  
        elif i in abc:
            aux = aux + abc[(abc.find(i) + 15) % 26]
        else:
            aux = aux + i

    return aux

def rot7(mensaje):
    mensaje = mensaje
    abc="abcdefghijklmnopqrstuvwxyz"
    aux=""

    for i in mensaje:
        if i == ' ':  
            aux += ' '  
        elif i in abc:
            aux = aux + abc[(abc.find(i) + 7) % 26]
        else:
            aux = aux + i

    return aux
    
def vigenere(mensaje, clave):
    abc = "abcdefghijklmnopqrstuvwxyz"
    mensaje = mensaje
    clave = clave
    aux = ""

    for i in range(len(mensaje)):
        if mensaje[i] == ' ':
            aux += ' '
        elif mensaje[i]:
            mensaje_idx = abc.find(mensaje[i])
            clave_idx = abc.find(clave[i % len(clave)])
            resultado_idx = (mensaje_idx + clave_idx) % 26
            if mensaje[i]:
                aux = aux + abc[resultado_idx]
            else:
                aux = aux + abc[resultado_idx]
        else:
            aux = aux + mensaje[i]

    return aux

#Cifrado
mensaje_entrada = "hola mundo"
rot15_cifrado = rot15(mensaje_entrada)
vigenere_password = "cvqnoteshrwnszhhksorbqcoas"
vigenere_cifrado = vigenere(rot15_cifrado, vigenere_password)
rot7_cifrado = rot7(vigenere_cifrado)
print("Mensaje cifrado:", rot7_cifrado)



def desrot15(mensaje):
    mensaje = mensaje
    abc="abcdefghijklmnopqrstuvwxyz"
    aux=""

    for i in mensaje:
        if i == ' ':  
            aux += ' '  
        elif i in abc:
            aux = aux + abc[(abc.find(i) - 15) % 26]
        else:
            aux = aux + i

    return aux


def desrot7(mensaje):
    mensaje = mensaje
    abc="abcdefghijklmnopqrstuvwxyz"
    aux=""

    for i in mensaje:
        if i == ' ':  
            aux += ' '  
        elif i in abc:
            aux = aux + abc[(abc.find(i) - 7) % 26]
        else:
            aux = aux + i

    return aux
    
def desvigenere(mensaje, clave):
    abc = "abcdefghijklmnopqrstuvwxyz"
    mensaje = mensaje
    clave = clave
    aux = ""

    for i in range(len(mensaje)):
        if mensaje[i] == ' ':
            aux += ' '
        elif mensaje[i]:
            mensaje_idx = abc.find(mensaje[i])
            clave_idx = abc.find(clave[i % len(clave)])
            resultado_idx = (mensaje_idx - clave_idx) % 26
            if mensaje[i]:
                aux = aux + abc[resultado_idx]
            else:
                aux = aux + abc[resultado_idx]
        else:
            aux = aux + mensaje[i]

    return aux


mensaje_cifrado = "ffxj bubgb"

    # Descifrado
mensaje_desencriptado_rot7 = desrot7(mensaje_cifrado)
mensaje_desencriptado_vigenere = desvigenere(mensaje_desencriptado_rot7, "cvqnoteshrwnszhhksorbqcoas")
mensaje_desencriptado_rot15 = desrot15(mensaje_desencriptado_vigenere)

print("Mensaje descifrado:", mensaje_desencriptado_rot15)
