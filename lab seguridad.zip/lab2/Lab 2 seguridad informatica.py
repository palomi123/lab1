import hashlib
def rot15(mensaje):
    abc="abcdefghijklmnopqrstuvwxyz"
    aux=""

    for i in mensaje:
        if i == ' ':  
            aux += ' '  
        elif i in abc:
            aux = aux + abc[(abc.find(i) + 15) % 26]
        else:
            aux = aux + i

    return aux



def desrot15(mensaje):
    abc="abcdefghijklmnopqrstuvwxyz"
    aux=""

    for i in mensaje:
        if i == ' ':  
            aux += ' '  
        elif i in abc:
            aux = aux + abc[(abc.find(i) - 15) % 26]
        else:
            aux = aux + i

    return aux

def leerArchivo(nombre):
    nombre = nombre + ".txt"
    archivo = open(nombre,'r')
    texto = ''
    for linea in archivo:
        texto = texto + linea
    archivo.close()
    return texto


'''se lee el contenido de un archivo de texto
utilizando la función leerArchivo() y se almacena en la variable mensaje'''
mensaje = leerArchivo("entrada")
'''el hash SHA-256 se ocupa para verificar la integridad 
del mensaje original después de cifrarlo y descifrarlo, asi no sea alterado'''
hash1 = hashlib.sha256(mensaje.encode()).hexdigest()
print("Mensaje:", mensaje)
print("Hash SHA-256:", hash1)
cifrado = rot15(mensaje)
print ("cifrado rot 15:", cifrado)

mensajeseguro = open("mensaje seguro.txt", 'a')
mensajeseguro.write(cifrado)
mensajeseguro.close()


#lee el archivo mensaje seguro
mensaje2 = leerArchivo("mensaje seguro")
descifrado = desrot15(mensaje2)
hash2 = hashlib.sha256(descifrado.encode()).hexdigest()
print("Mensaje descrifado:", descifrado)
print("Hash SHA-256:", hash2)

if hash1 == hash2:
    print("Los cifrados son idénticos")
else:
    print("No son iguales")
